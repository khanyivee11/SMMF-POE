# Soweto Men's Manners Forum – Companion Project

This folder completes four web-development tasks for the Soweto Men's Manners Forum site.
The original file, `soweto-manners-forum.html`, was **not changed**. Everything here is new.

## Folder structure

```
soweto-forum-project/
├── index.html        Home page (programmes, searchable focus areas, FAQ)
├── contact.html      Enquiry form page
├── css/
│   └── styles.css    Shared styles
├── js/
│   ├── main.js       Site interactivity
│   └── validation.js Form validation
├── images/           11 pictures extracted from the original HTML
│   ├── image-01.jpg … image-11.jpg  (image-02.png looks like the logo)
├── robots.txt        Search-engine crawl rules
├── sitemap.xml       List of pages for search engines
└── README.md         This file
```

## The four tasks

### 1. Implement JavaScript to add functionality and interaction
File: `js/main.js`
- Mobile menu button (with `aria-expanded`; closes on Esc)
- Focus-area search box and category filter buttons, with a live "N focus areas shown" count
- Back-to-top button that appears after scrolling
- Footer year updates automatically
- FAQ accordion uses native `<details>` elements

### 2. Apply SEO best practices
Files: `index.html`, `contact.html`, `robots.txt`, `sitemap.xml`
- Unique `<title>` and meta description on every page
- Canonical link, Open Graph and Twitter Card tags
- JSON-LD structured data (`NGO`) on the home page
- Semantic HTML: one `h1` per page, `header`, `nav`, `main`, `section`, `article`, `footer`
- `lang="en-ZA"`, mobile viewport tag, skip-to-content link
- `robots.txt` and `sitemap.xml`

### 3. Create forms with HTML code
File: `contact.html`
- Text, email, tel, dropdown (`select`), radio group, textarea and checkbox
- Every field has a `<label>`; the radio group uses `<fieldset>` and `<legend>`
- Uses `autocomplete` attributes and appropriate input types

### 4. Build JavaScript validation into forms
File: `js/validation.js`
- Name: required, at least 2 characters, letters only
- Email: required, valid format
- Phone: optional, South African format (`069 123 4567` or `+27 69 123 4567`)
- Topic: must be chosen
- Reply method: one option must be selected
- Message: 10–500 characters, with a live counter
- Consent checkbox: must be ticked
- Errors appear next to each field, the first invalid field receives focus, and fields re-check as the user fixes them

## How to run
Open `index.html` in any browser. No build step or server is needed. Internet is only needed for the Google Fonts.

## Things to know
- **Placeholder domain:** `https://www.example.org/` appears in the canonical links, `sitemap.xml`, `robots.txt` and the JSON-LD. Replace it with the real website address.
- **Form sending:** the form is not connected to a sending service (same as the original site). Valid submissions show a confirmation message only; nothing is sent.
- **Images:** the pictures in `images/` are extracted but not yet used in the pages. When added, give each an `alt` description for accessibility and SEO.
- **Contact details:** only details from the original site are used (phone/WhatsApp 069 173 6005). The email address on the original site contains a space, so it was left out until confirmed.
