/* Interactivity for the Soweto Men's Manners Forum companion pages. */
(function () {
  "use strict";

  // 1. Mobile navigation toggle (keeps aria-expanded in sync)
  var toggle = document.getElementById("menu-toggle");
  var menu = document.getElementById("menu");
  if (toggle && menu) {
    toggle.addEventListener("click", function () {
      var open = menu.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && menu.classList.contains("open")) {
        menu.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.focus();
      }
    });
  }

  // 2. Focus-area search + category filter
  var search = document.getElementById("focus-search");
  var cards = Array.prototype.slice.call(document.querySelectorAll("[data-focus]"));
  var count = document.getElementById("focus-count");
  var filterBtns = Array.prototype.slice.call(document.querySelectorAll(".filters button"));
  var category = "all";

  function applyFilters() {
    var q = search ? search.value.trim().toLowerCase() : "";
    var shown = 0;
    cards.forEach(function (c) {
      var matchCat = category === "all" || c.dataset.category === category;
      var matchText = !q || c.textContent.toLowerCase().indexOf(q) !== -1;
      c.hidden = !(matchCat && matchText);
      if (!c.hidden) shown++;
    });
    if (count) count.textContent = shown + (shown === 1 ? " focus area shown" : " focus areas shown");
  }
  if (cards.length) {
    if (search) search.addEventListener("input", applyFilters);
    filterBtns.forEach(function (b) {
      b.addEventListener("click", function () {
        category = b.dataset.filter;
        filterBtns.forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
        applyFilters();
      });
    });
    applyFilters();
  }

  // 3. Back-to-top button appears after scrolling
  var top = document.getElementById("top");
  if (top) {
    window.addEventListener("scroll", function () {
      top.style.display = window.scrollY > 600 ? "block" : "none";
    }, { passive: true });
    top.addEventListener("click", function () { window.scrollTo({ top: 0 }); });
  }

  // 4. Footer year
  var y = document.getElementById("year");
  if (y) y.textContent = new Date().getFullYear();
})();
